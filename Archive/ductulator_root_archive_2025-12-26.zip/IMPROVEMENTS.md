# Improvement Review Checklist

Add Priority (1 = highest), Decision (do/skip/park), and Notes under each bullet.

- Fix HTML structure issues (header inside body, remove stray `<td>` in footer, add labels)
  - Priority:1
  - Decision:do
  - Notes:
- Replace obfuscated `myscript.js` and remove `eval` prompt
  - Priority:2
  - Decision: already updated to un obuscated, please format, comment, remove unnessesary comments, consolidate with ductscript.js, we want to replace .js files with assembly wasm
  - Notes:
- Clean up validation + event handling (centralized handlers, clearer errors)
  - Priority:3
  - Decision:do
  - Notes:
- Consolidate duplicated assets between root and `metric/`
  - Priority:4
  - Decision:hold off for now
  - Notes:
- Improve UX/responsiveness/accessibility (grid sizing, contrast, footer overlap, ARIA)
  - Priority:5
  - Decision:do
  - Notes:
- Add proper Google AdSense unit (approved domain, `<ins class="adsbygoogle">` + `adsbygoogle.push`)
  - Priority:6
  - Decision:do
  - Notes:
